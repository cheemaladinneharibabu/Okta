# Okta_SAML_Example

This is the companion repo for my blog [How to Authenticate with SAML in ASP.NET Core and C#](https://developer.okta.com/blog/2020/10/23/how-to-authenticate-with-saml-in-aspnet-core-and-csharp)

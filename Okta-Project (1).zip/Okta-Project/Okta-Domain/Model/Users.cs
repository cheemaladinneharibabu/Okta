﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okta_Domain.Model
{
    public class Users
    {
        public string User_type { get; set; }
        public string Username { get; set; }
    }
}

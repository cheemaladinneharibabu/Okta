﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Okta_ClientFlowDotNetSix.Models;
using Okta_Domain.Model;
using Okta_Infrastructure.Data;

namespace Okta_ClientFlowDotNetSix.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Policy = "OnlyAdminandBMW")]

    public class BMWController : Controller
        
    {
        private readonly CarDbContext _context;
        public BMWController(CarDbContext context)
        {
            _context = context;
        }

        [HttpGet("Get")]
   
        public IActionResult GetCars()
        {
            var userRoles = User.Claims.Where(c => c.Type == "groups").Select(c => c.Value).ToList();
            Console.WriteLine("User Roles: " + string.Join(", ", userRoles));
            var ferrariCars = _context.bmw.ToList();
            return Ok(ferrariCars);
        }

        [HttpGet("{id}")]
      
        public IActionResult GetCarById(int id)
        {
            var car = _context.bmw.FirstOrDefault(c => c.Id == id);
            if (car == null)
            {
                return NotFound();
            }
            return Ok(car);
        }

        [HttpPost]
       
        public IActionResult AddCar([FromBody] BMW car)
        {
            _context.bmw.Add(car);
            _context.SaveChanges();
            return Ok("Car added successfully");
        }

        [HttpPut("{id}")]
       
        public IActionResult UpdateCar(int id, [FromBody] BMW car)
        {
            var existingCar = _context.bmw.FirstOrDefault(c => c.Id == id);
            if (existingCar == null)
            {
                return NotFound();
            }
            existingCar.Mileage = car.Mileage;
            existingCar.Make = car.Make;
            existingCar.Model = car.Model;
            existingCar.Year = car.Year;
            existingCar.Price = car.Price;
            _context.SaveChanges();

            return Ok($"Car with ID {id} updated successfully");
        }

        [HttpDelete("{id}")]
        
        public IActionResult DeleteCar(int id)
        {
            var car = _context.bmw.FirstOrDefault(c => c.Id == id);
            if (car == null)
            {
                return NotFound();
            }

            _context.bmw.Remove(car);
            _context.SaveChanges();

            return Ok($"Car with ID {id} deleted successfully");
        }
    }
}

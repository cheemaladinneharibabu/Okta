﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Okta_ClientFlowDotNetSix.Models;
using Okta_Domain.Model;
using Okta_Infrastructure.Data;

namespace Okta_ClientFlowDotNetSix.Controllers
{
    public class PorscheController : Controller
    {
        private readonly CarDbContext _context;
        public PorscheController(CarDbContext context)
        {
            _context = context;
        }

        [HttpGet("Get")]
        [Authorize(Policy = "OnlyPorscheandAdmin")]
        public IActionResult GetCars()
        {
            var userRoles = User.Claims.Where(c => c.Type == "groups").Select(c => c.Value).ToList();
            Console.WriteLine("User Roles: " + string.Join(", ", userRoles));
            var porscheCars = _context.porsche.ToList();
            return Ok(porscheCars);
        }

        [HttpGet("{id}")]
        [Authorize(Policy = "OnlyPorscheandAdmin")]
        public IActionResult GetCarById(int id)
        {
            var car = _context.porsche.FirstOrDefault(c => c.Id == id);
            if (car == null)
            {
                return NotFound();
            }
            return Ok(car);
        }

        [HttpPost]
        [Authorize(Policy = "OnlyAdminandManagerFerrari")]
        public IActionResult AddCar([FromBody] Porsche car)
        {
            _context.porsche.Add(car);
            _context.SaveChanges();
            return Ok("Car added successfully");
        }

        [HttpPut("{id}")]
        [Authorize(Policy = "OnlyPorscheandAdmin")]
        public IActionResult UpdateCar(int id, [FromBody] Porsche car)
        {
            var existingCar = _context.porsche.FirstOrDefault(c => c.Id == id);
            if (existingCar == null)
            {
                return NotFound();
            }
            existingCar.Mileage = car.Mileage;
            existingCar.Make = car.Make;
            existingCar.Model = car.Model;
            existingCar.Year = car.Year;
            existingCar.Price = car.Price;
            _context.SaveChanges();

            return Ok($"Car with ID {id} updated successfully");
        }

        [HttpDelete("{id}")]
        [Authorize(Policy = "OnlyPorscheandAdmin")]
        public IActionResult DeleteCar(int id)
        {
            var car = _context.porsche.FirstOrDefault(c => c.Id == id);
            if (car == null)
            {
                return NotFound();
            }

            _context.porsche.Remove(car);
            _context.SaveChanges();

            return Ok($"Car with ID {id} deleted successfully");
        }
    }
}

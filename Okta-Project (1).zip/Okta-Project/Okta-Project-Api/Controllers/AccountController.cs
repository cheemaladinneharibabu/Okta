﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Okta_Service.Interface;
using System.Net.Http.Headers;
using System.Net.Http;
using Okta_Domain.Model;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;

namespace Okta_Project_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly ITokenService _tokenService;
        private readonly IHttpClientFactory _httpClientFactory;
        public AccountController(ITokenService tokenService, IHttpClientFactory httpClientFactory)
        {
            _tokenService = tokenService;
            _httpClientFactory = httpClientFactory;
        }
        [HttpGet("Get-Token")]
        public async Task<IActionResult> SignInAndGetToken(string username, string password)
        {
            var oktaToken = await _tokenService.GetToken(username, password);

            if (oktaToken != null)
            {
                return Ok(oktaToken);
            }
            return null;
        }

    }
}

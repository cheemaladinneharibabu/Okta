﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Okta_Domain.Model;
using Okta_Infrastructure.Data;

namespace Okta_Project_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "OnlylandroverandAdmin")]
    public class landroverController : ControllerBase
    {
        private readonly CarDbContext _context;

        public landroverController(CarDbContext carDbContext)
        {
            _context = carDbContext;
        }

        [HttpGet("Get")]

        public IActionResult GetCars()
        {
            var userRoles = User.Claims.Where(c => c.Type == "groups").Select(c => c.Value).ToList();
            Console.WriteLine("User Roles: " + string.Join(", ", userRoles));
            var landroverCars = _context.landrovers.ToList();
            return Ok(landroverCars);
        }

        [HttpGet("{id}")]

        public IActionResult GetCarById(int id)
        {
            var car = _context.landrovers.FirstOrDefault(c => c.Id == id);
            if (car == null)
            {
                return NotFound();
            }
            return Ok(car);
        }

        [HttpPost]

        public IActionResult AddCar([FromBody] Landrover car)
        {
            _context.landrovers.Add(car);
            _context.SaveChanges();
            return Ok("Car added successfully");
        }

        [HttpPut("{id}")]

        public IActionResult UpdateCar(int id, [FromBody] Landrover car)
        {
            var existingCar = _context.landrovers.FirstOrDefault(c => c.Id == id);
            if (existingCar == null)
            {
                return NotFound();
            }
            existingCar.Mileage = car.Mileage;
            existingCar.Make = car.Make;
            existingCar.Model = car.Model;
            existingCar.Year = car.Year;
            existingCar.Price = car.Price;
            _context.SaveChanges();

            return Ok($"Car with ID {id} updated successfully");
        }

        [HttpDelete("{id}")]

        public IActionResult DeleteCar(int id)
        {
            var car = _context.landrovers.FirstOrDefault(c => c.Id == id);
            if (car == null)
            {
                return NotFound();
            }

            _context.landrovers.Remove(car);
            _context.SaveChanges();

            return Ok($"Car with ID {id} deleted successfully");
        }

    }
}

﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly IHttpClientFactory _httpClientFactory;

    public UserController(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    [HttpGet]

    public async Task<IActionResult> GetUsers()
    {
        var client = _httpClientFactory.CreateClient();
       
       

        var response = await client.GetAsync("https://dev-77192571.okta.com/api/v1/users");
        if (response.IsSuccessStatusCode)
        {
            var users = await response.Content.ReadFromJsonAsync<object>(); // You can replace 'object' with a class representing the response structure
            return Ok(users);
        }
        else
        {
            return StatusCode((int)response.StatusCode, response.ReasonPhrase);
        }
    }
}

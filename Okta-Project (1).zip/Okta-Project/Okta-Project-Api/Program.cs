using Microsoft.OpenApi.Models;
using Okta_Domain.Model;
using Okta_Service.Interface;
using Okta_Service.Services;
using Okta_Infrastructure.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Okta.AspNetCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.AddConsole();


// Add services to the container.
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Your API", Version = "v1" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "Okta Authorization header using the Bearer scheme.",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer"

    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Name="Bearer",
                    Type= SecuritySchemeType.ApiKey,
                    In=ParameterLocation.Header,

                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"

                    }
                },
                Array.Empty<string>()
            }
        });
});

builder.Services.Configure<OktaTokenSettings>(builder.Configuration.GetSection("Okta"));
var oktaSettings = builder.Configuration.GetSection("Okta").Get<OktaTokenSettings>();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
})

.AddOktaWebApi(new Okta.AspNetCore.OktaWebApiOptions
{

    OktaDomain = oktaSettings.Domain,
    AuthorizationServerId = oktaSettings.AuthorizationServerId,
    Audience = oktaSettings.Audience,

});

builder.Services.AddSingleton<Okta_Service.Interface.ITokenService, TokenService>();
builder.Services.AddHttpClient();
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("All", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin", "Managers" }));
    });
    options.AddPolicy("OnlyAdminandManager", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin", "Managers" }));
    });
    options.AddPolicy("OnlyAdmin", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin" }));
    });
    options.AddPolicy("OnlyAdminandBMW", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin", "BMW" }));
    });
    options.AddPolicy("OnlylandroverandAdmin", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Landrover", "Admin" }));
    });
    options.AddPolicy("OnlyPorscheandAdmin", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Porsche", "Admin" }));
    });
    options.AddPolicy("OnlyMercedesandAdmin", policy =>
    {
        policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Mercedes", "Admin" }));
    });


});

builder.Services.AddSingleton<IAuthorizationHandler, CustomAuthorizationHandler>();


builder.Services.AddDbContext<CarDbContext>(db => db.UseSqlServer(builder.Configuration.GetConnectionString("CarCon")));


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<MyHttpClient>();
builder.Services.Configure<Okta_Domain.Model.OktaJwtVerificationOptions>(
builder.Configuration.GetSection("Okta"));
builder.Services.AddScoped<IJwtValidator, OktaJwtValidation>();


builder.Services.AddTransient<Okta_Service.Interface.IJwtValidator, Okta_Service.Services.OktaJwtValidation>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors(options => options.AllowAnyOrigin().AllowAnyMethod()
                 .AllowAnyHeader());
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
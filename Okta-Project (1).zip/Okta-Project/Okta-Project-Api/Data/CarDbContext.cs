﻿using Microsoft.EntityFrameworkCore;
using Okta_ClientFlowDotNetSix.Models;
using Okta_Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace Okta_Infrastructure.Data
{
    public class CarDbContext : DbContext
    {
        public CarDbContext(DbContextOptions<CarDbContext> options) : base(options)
        {
        }

        public DbSet<Car> Cars { get; set; }
        public DbSet<Porsche> porsche { get; set; }
        public DbSet<BMW> bmw { get; set; }
        public DbSet<Landrover> landrovers { get; set; }
        public DbSet<Mercedes> mercedes { get; set; }




    }
}

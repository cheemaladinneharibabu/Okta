﻿using Okta_Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okta_Service.Interface
{
    public interface ITokenService
    {
        Task<OktaResponse> GetToken(string Username, string Password);
    }
}

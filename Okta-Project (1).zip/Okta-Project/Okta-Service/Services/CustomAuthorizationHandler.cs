﻿using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class CustomAuthorizationHandler : AuthorizationHandler<CustomAuthorizationRequirement>
{
	protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, CustomAuthorizationRequirement requirement)
	{
		if (context.User.HasClaim(c => c.Type == "groups"))
		{
			var groups = context.User.Claims.Where(c => c.Type == "groups").Select(c => c.Value).ToList();
			if (groups.Any(group => requirement.RequiredRoles.Contains(group)))
			{
				context.Succeed(requirement);
			}
		}

		return Task.CompletedTask;
	}
}

public class CustomAuthorizationRequirement : IAuthorizationRequirement
{
	public List<string> RequiredRoles { get; }

	public CustomAuthorizationRequirement(List<string> requiredRoles)
	{
		RequiredRoles = requiredRoles;
	}
}

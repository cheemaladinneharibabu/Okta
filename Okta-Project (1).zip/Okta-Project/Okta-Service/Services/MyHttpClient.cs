﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okta_Service.Services
{
    public class MyHttpClient
    {
        private readonly HttpClient _httpClient;

        public MyHttpClient()
        {
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };

            // Create the HttpClient with the custom handler
            _httpClient = new HttpClient(handler);
        }

        public HttpClient GetHttpClient()
        {
            return _httpClient;
        }
    }
}

﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Okta_ClientFlowDotNetSix.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Okta_ClientFlowDotNetSix.Services
{
	public class TokenService : ITokenService
	{
		private readonly IOptions<OktaTokenSettings> _options;
		private readonly ILogger<TokenService> _logger;
		public TokenService(IOptions<OktaTokenSettings> options, ILogger<TokenService> logger)
		{
			_options = options;
			_logger = logger;
		}

		public async Task<OktaResponse> GetToken(string username, string password)
		{
			var token = new OktaResponse();
			var client = new HttpClient();
			var client_id = _options.Value.ClientId;
			var client_secret = _options.Value.ClientSecret;
			var clientCreds = Encoding.UTF8.GetBytes($"{client_id}:{client_secret}");
			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(clientCreds));
			client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			var postMessage = new Dictionary<string, string>
			{
				{ "grant_type", "password" },
				{ "username", username },
				{ "password", password },
				{ "scope", "openid api groups" }
			};
			var request = new HttpRequestMessage(HttpMethod.Post, $"{_options.Value.Domain}/oauth2/default/v1/token")
			{
				Content = new FormUrlEncodedContent(postMessage)
			};
			var response = await client.SendAsync(request);
			if (response.IsSuccessStatusCode)
			{
				var jsonSerializerSetting = new JsonSerializerSettings();
				var json = await response.Content.ReadAsStringAsync();
				token = JsonConvert.DeserializeObject<OktaResponse>(json, jsonSerializerSetting);
				token.ExpiresAt = DateTime.UtcNow.AddSeconds(token.ExpiresIn);

				// Extract the groups (roles) from the access token claims
				var groups = GetGroupsFromAccessToken(token.AccessToken);


				_logger.LogInformation($"Groups for this user: {string.Join(", ", groups)}");
				token.Roles = groups;
				
			}
			else
			{
				var error = await response.Content?.ReadAsStringAsync();
				throw new ApplicationException(error);
			}
			return token;
		}

		private List<string> GetGroupsFromAccessToken(string accessToken)
		{
			var handler = new JwtSecurityTokenHandler();
			var token = handler.ReadJwtToken(accessToken);

			var groups = token.Claims.Where(c => c.Type == "groups").Select(c => c.Value).ToList();


			return groups;
		}
	}
}

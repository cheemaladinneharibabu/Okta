﻿using Microsoft.AspNetCore.Mvc;
using Okta_ClientFlowDotNetSix.Models;

namespace Okta_ClientFlowDotNetSix.Services
{
	public interface ITokenService
	{ 
		Task<OktaResponse> GetToken(string Username , string Password);
	}
}

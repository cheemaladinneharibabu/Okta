﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Okta_ClientFlowDotNetSix.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Okta_ClientFlowDotNetSix.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	//[Authorize]
	public class CarController : ControllerBase
	{
		private readonly CarDbContext _context;
		

		public CarController(CarDbContext context)
		{
			_context = context;
		
		}

		[HttpGet]
		[Authorize(Policy = "All")]
		public IActionResult GetCars()
		{

			var userRoles = User.Claims.Where(c => c.Type == "groups").Select(c => c.Value).ToList();
			Console.WriteLine("User Roles: " + string.Join(", ", userRoles));
			var cars = _context.Cars.ToList();
			return Ok(cars);
		}

		[HttpGet("{id}")]
		[Authorize(Policy = "OnlyAdminandManager")]
		public IActionResult GetCarById(int id)
		{
			var car = _context.Cars.FirstOrDefault(c => c.Id == id);
			if (car == null)
			{
				return NotFound();
			}
			return Ok(car);
		}

		[HttpPost]
		[Authorize(Policy = "OnlyAdminandManager")]
		public IActionResult AddCar([FromBody] Car car)
		{
			_context.Cars.Add(car);
			_context.SaveChanges();
			return Ok("Car added successfully");
		}

		[HttpPut("{id}")]
		[Authorize(Policy = "OnlyAdmin")]
		public IActionResult UpdateCar(int id, [FromBody] Car car)
		{
			var existingCar = _context.Cars.FirstOrDefault(c => c.Id == id);
			if (existingCar == null)
			{
				return NotFound();
			}
			existingCar.Mileage = car.Mileage;
			existingCar.Make = car.Make;
			existingCar.Model = car.Model;
			existingCar.Year = car.Year;
			existingCar.Price = car.Price;
			

			_context.SaveChanges();

			return Ok($"Car with ID {id} updated successfully");
		}

		[HttpDelete("{id}")]
		[Authorize(Policy = "OnlyAdmin")]
		public IActionResult DeleteCar(int id)
		{
			var car = _context.Cars.FirstOrDefault(c => c.Id == id);
			if (car == null)
			{
				return NotFound();
			}

			_context.Cars.Remove(car);
			_context.SaveChanges();

			return Ok($"Car with ID {id} deleted successfully");
		}
	}
}


﻿using System.Net.Http;
using System.Net.Security;

namespace Okta_ClientFlowDotNetSix.Okta
{
	public class MyHttpClient
	{
		private readonly HttpClient _httpClient;

		public MyHttpClient()
		{
			// Create a handler that ignores SSL certificate validation
			var handler = new HttpClientHandler
			{
				ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
			};

			// Create the HttpClient with the custom handler
			_httpClient = new HttpClient(handler);
		}

		public HttpClient GetHttpClient()
		{
			return _httpClient;
		}
	}
}


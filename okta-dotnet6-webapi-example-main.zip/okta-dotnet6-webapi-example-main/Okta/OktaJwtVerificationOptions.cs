﻿namespace Okta_ClientFlowDotNetSix.Okta
{
    public class OktaJwtVerificationOptions
    {
        public string Issuer { get; set; }
    }
}

using FluentAssertions.Common;
using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Models;
using Okta_ClientFlowDotNetSix.Okta;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Okta_ClientFlowDotNetSix.Models;
using Okta.AspNet.Abstractions;
using Okta.AspNetCore;
using Okta_ClientFlowDotNetSix.Services;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.AddConsole();


// Add services to the container.
builder.Services.AddSwaggerGen(c =>
{
	c.SwaggerDoc("v1", new OpenApiInfo { Title = "Your API", Version = "v1" });

	c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
	{
		Description = "Okta Authorization header using the Bearer scheme.",
		Type = SecuritySchemeType.Http,
		Scheme = "bearer"

	});

	c.AddSecurityRequirement(new OpenApiSecurityRequirement
		{
			{
				new OpenApiSecurityScheme
				{
					Name="Bearer",
					Type= SecuritySchemeType.ApiKey,
					In=ParameterLocation.Header,

					Reference = new OpenApiReference
					{
						Type = ReferenceType.SecurityScheme,
						Id = "Bearer"

					}
				},
				Array.Empty<string>()
			}
		});
});

builder.Services.Configure<OktaTokenSettings>(builder.Configuration.GetSection("Okta"));
var oktaSettings = builder.Configuration.GetSection("Okta").Get<OktaTokenSettings>();

builder.Services.AddAuthentication(options =>
{
	options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
	options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
	options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
})

.AddOktaWebApi(new Okta.AspNetCore.OktaWebApiOptions
{

	OktaDomain = oktaSettings.Domain,
	AuthorizationServerId = oktaSettings.AuthorizationServerId,
	Audience = oktaSettings.Audience,

});
//.AddJwtBearer(options =>
//{
//	Configure your JWT bearer authentication options
//	options.Authority = "https://dev-38617275.okta.com/oauth2/default";
//	options.Audience = "api://default";
//	options.TokenValidationParameters = new TokenValidationParameters
//	{
//		ValidateIssuer = true,
//		ValidateAudience = true,
//		ValidateIssuerSigningKey = true,
//		ValidateLifetime = true
//	};
//});






builder.Services.AddSingleton<Okta_ClientFlowDotNetSix.Services.ITokenService, TokenService>();

builder.Services.AddAuthorization(options =>
{
	options.AddPolicy("All", policy =>
	{
		policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin", "Manager", "Users" }));
	});
	options.AddPolicy("OnlyAdminandManager", policy =>
	{
		policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin", "Manager"}));
	});
	options.AddPolicy("OnlyAdmin", policy =>
	{
		policy.Requirements.Add(new CustomAuthorizationRequirement(new List<string> { "Admin" }));
	});
});

builder.Services.AddSingleton<IAuthorizationHandler, CustomAuthorizationHandler>();

builder.Services.AddDbContext<CarDbContext>(db => db.UseSqlServer(builder.Configuration.GetConnectionString("CarCon")));


   builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
   builder.Services.AddEndpointsApiExplorer();
   builder.Services.AddSwaggerGen();
   builder.Services.AddSingleton<MyHttpClient>();
   builder.Services.Configure<Okta_ClientFlowDotNetSix.Okta.OktaJwtVerificationOptions>(
  builder.Configuration.GetSection("Okta"));
   builder.Services.AddScoped<IJwtValidator, OktaJwtValidation>();


builder.Services.AddTransient<Okta_ClientFlowDotNetSix.Okta.IJwtValidator, Okta_ClientFlowDotNetSix.Okta.OktaJwtValidation>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();